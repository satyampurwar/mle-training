"""
Notes
-----
This package contains files for data ingestion, model training and data scoring on housing data.
"""
